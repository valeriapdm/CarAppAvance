package arrendadoras;

public class vehiculoArrendadoraEmpresa {
}
