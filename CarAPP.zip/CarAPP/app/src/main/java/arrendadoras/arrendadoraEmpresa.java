package arrendadoras;

public class arrendadoraEmpresa {
}
