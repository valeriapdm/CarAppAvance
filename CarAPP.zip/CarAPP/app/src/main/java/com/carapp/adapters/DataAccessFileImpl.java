package com.carapp.adapters;

import android.content.Context;

import com.carapp.datosuser.Usuario;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class DataAccessFileImpl implements DataAccessAdapter {

    private String fileName = "Usuarios.txt";

    @Override
    public String[] getUserData(String userName, Object context) {
        String[] userResult = null;
        InputStream inputStream = null;

        try {
            inputStream = ((Context)context).openFileInput(fileName);

            if ( inputStream != null ) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receivedString = "";
                StringBuilder stringBuilder = new StringBuilder();

                while ( (receivedString = bufferedReader.readLine()) != null ) {
                    String campos[] = receivedString.split("\\|");
                    if (campos[0].trim().equals(userName.trim())) {
                        userResult = receivedString.split("\\|");
                    }
                }
            }
        }
        catch (Exception e) {
        } finally {
            try {
                inputStream.close();
            } catch (Exception e1) {
            }
        }
        return userResult;
    }

    @Override
    public void saveUserData(Usuario user, Object context) {
        OutputStreamWriter outputStreamWriter = null;

        try {
            outputStreamWriter = new OutputStreamWriter(((Context)context).openFileOutput(this.fileName, Context.MODE_APPEND));
            outputStreamWriter.write(user.getDataString() + "\n");
        } catch (Exception e) {

        } finally {
            try {
                outputStreamWriter.close();
            } catch (Exception e1) {
            }
        }
    }
}
