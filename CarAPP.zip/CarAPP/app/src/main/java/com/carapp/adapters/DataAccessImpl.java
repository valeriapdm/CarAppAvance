package com.carapp.adapters;

import com.carapp.datosuser.Usuario;

public class DataAccessImpl implements DataAccessAdapter {

    private static final int type = 1; // 1 File Adapter - 2 DataBase
    private DataAccessAdapter acessAdaper = null;

    public DataAccessImpl() {
        switch (type) {
            case 1:
                acessAdaper = new DataAccessFileImpl();
                break;
            case 2:
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + type);
        }
    }
    
    @Override
    public String[] getUserData(String userName, Object context) {
        return acessAdaper.getUserData(userName, context);
    }

    @Override
    public void saveUserData(Usuario user, Object context) {
        acessAdaper.saveUserData(user, context);
    }
}
