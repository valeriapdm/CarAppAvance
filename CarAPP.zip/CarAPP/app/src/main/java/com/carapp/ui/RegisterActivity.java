package com.carapp.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.carapp.R;
import com.carapp.datosuser.Usuario;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        getSupportActionBar().setTitle(R.string.register_action);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }

    public void processRegistry(View view) {
        Usuario usuario = new Usuario(
                ((EditText)findViewById(R.id.userName)).getText().toString().trim(),
                ((EditText)findViewById(R.id.name)).getText().toString().trim(),
                ((EditText)findViewById(R.id.lastName)).getText().toString().trim(),
                ((EditText)findViewById(R.id.password)).getText().toString().trim(),
                ((EditText)findViewById(R.id.phone)).getText().toString().trim(),
                ((EditText)findViewById(R.id.email)).getText().toString().trim());
        usuario.CrearUsuario(view.getContext());
        Toast.makeText(getApplicationContext(), "Usuario " + usuario.getUserName() + " Registrado", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
