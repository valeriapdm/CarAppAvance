package com.carapp.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.carapp.R;

public class SplashScreenCarApp extends AppCompatActivity {

    private final int Duracion_splash = 5000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen_car_app);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashScreenCarApp.this, MainActivity.class);
                startActivity(intent);
                finish();

            };
        }, Duracion_splash);
    }
}
