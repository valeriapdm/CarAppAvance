package com.carapp.adapters;

import com.carapp.datosuser.Usuario;

public interface DataAccessAdapter {

    public String[] getUserData(String userName, Object context);

    public void saveUserData(Usuario user, Object context);

}
